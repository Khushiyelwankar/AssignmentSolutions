
import React from 'react';
import ReactDOM from 'react-dom/client';
import CohortDetails from './components/CohortDetails';

const root = ReactDOM.createRoot(document.getElementById('root'));

const cohorts = [
  { name: "React Bootcamp", status: "ongoing", startDate: "2025-07-01", endDate: "2025-08-01" },
  { name: "Node.js Bootcamp", status: "completed", startDate: "2025-05-01", endDate: "2025-06-01" }
];

root.render(
  <div>
    {cohorts.map((cohort, index) => (
      <CohortDetails key={index} cohort={cohort} />
    ))}
  </div>
);
