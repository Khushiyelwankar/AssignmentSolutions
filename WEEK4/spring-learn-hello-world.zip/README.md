# Hello World RESTful Web Service

## Task:
Spring Learn Application me ek REST API create karni hai jo `Hello World!!` return kare.

### ✅ Details:
- **Method:** GET
- **URL:** /hello
- **Controller:** com.cognizant.springlearn.controller.HelloController
- **Method Signature:** public String sayHello()
- **Implementation:** return "Hello World!!"

### ✅ Steps:
1. `HelloController` create kiya with `@RestController`.
2. `@GetMapping("/hello")` use karke GET endpoint banaya.
3. Logging add kiya method ke start aur end me.
4. `application.properties` me server port 8083 set kiya.

### ✅ Test URL:
- Browser/Postman me open karo: `http://localhost:8083/hello`
- Response: `Hello World!!`

### 🔍 SME Explanation:
- **Network Tab (Chrome DevTools):** Response ke HTTP headers check karne ke liye.
- **Postman:** Headers tab me jaake HTTP headers verify karo.

