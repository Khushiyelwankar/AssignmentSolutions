# Spring Core - Load Country from Spring Configuration XML

## Problem Statement
Airlines website ke liye 4 countries ka data store karna hai jisme code aur name hoga.
Example:
- US - United States
- DE - Germany
- IN - India
- JP - Japan

## Steps Implemented:
1. `country.xml` me Country bean create kiya.
2. `Country` class banayi jisme code aur name variables hai, constructor me debug log.
3. Getters/Setters me debug logs add kiye aur toString override kiya.
4. `displayCountry()` method `SpringLearnApplication.java` me banayi jo XML se bean load karti hai aur display karti hai.
5. `main()` method me `displayCountry()` invoke kiya.

## Key Concepts:
- **bean tag:** Object ko define karne ke liye.
- **id attribute:** Bean ka unique identifier.
- **class attribute:** Kaunsa Java class use hoga bean ke liye.
- **property tag:** Bean ke fields ko set karne ke liye.
- **ApplicationContext:** Spring container jo beans ko manage karta hai.
- **ClassPathXmlApplicationContext:** XML configuration se beans load karta hai.
- **context.getBean():** Spring container se bean instance nikalne ke liye use hota hai.

