# Spring Learn Project (Hinglish Version)

Ye ek **Spring Web Project** hai jo Maven use karke banaya gaya hai (Cognizant Digital Nurture Program ke liye).

---

## 🚀 Project Kaise Create Kare?

### 1️⃣ Spring Boot Project Generate Karo
1. [https://start.spring.io/](https://start.spring.io/) open karo.
2. Ye values set karo:
   - **Group:** `com.cognizant`
   - **Artifact:** `spring-learn`
3. Dependencies add karo:
   - Spring Boot DevTools
   - Spring Web
4. **Generate** pe click karke `.zip` file download karo.

---

### 2️⃣ Eclipse Me Setup Karo
1. `.zip` file extract karo apne Eclipse workspace me.
2. Command prompt me jaake project root folder open karo aur ye command run karo:
   ```bash
   mvn clean package -Dhttp.proxyHost=proxy.cognizant.com -Dhttp.proxyPort=6050 -Dhttps.proxyHost=proxy.cognizant.com -Dhttps.proxyPort=6050 -Dhttp.proxyUser=123456
   ```
3. Eclipse me import karo:
   - **File > Import > Maven > Existing Maven Projects > Browse > Extracted Folder Select Karo > Finish**

---

### 3️⃣ Application Run Karo
1. `SpringLearnApplication.java` file open karo.
2. Logging add karo taki verify ho sake ki `main()` method run ho raha hai:
   ```java
   package com.cognizant.springlearn;

   import org.springframework.boot.SpringApplication;
   import org.springframework.boot.autoconfigure.SpringBootApplication;
   import org.slf4j.Logger;
   import org.slf4j.LoggerFactory;

   @SpringBootApplication
   public class SpringLearnApplication {

       private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);

       public static void main(String[] args) {
           LOGGER.info("Spring Learn Application Start Ho Raha Hai...");
           SpringApplication.run(SpringLearnApplication.class, args);
           LOGGER.info("Spring Learn Application Successfully Start Ho Gaya!");
       }
   }
   ```
3. Right-click karo → **Run As → Java Application**

---

## 📂 Project Structure (Folders)

```
spring-learn/
│── src/
│   ├── main/
│   │   ├── java/                # Application ka main code
│   │   │   └── com/cognizant/springlearn/
│   │   │       └── SpringLearnApplication.java
│   │   └── resources/           # Application configuration files
│   └── test/
│       └── java/                # Testing ka code
│
│── pom.xml                      # Maven ka configuration file
```

---

## 🔍 Important Points

### ✅ **SpringLearnApplication.java**
- `main()` method yahan hai jo Spring Boot application start karta hai.
- `@SpringBootApplication` annotation lagaya hai.

### ✅ **@SpringBootApplication**
- Teen annotations combine karta hai: `@Configuration`, `@EnableAutoConfiguration`, aur `@ComponentScan`.
- Isko entry point ke liye use karte hain.

### ✅ **pom.xml**
- Maven ke dependencies aur plugins yahan define hote hain.

Example snippet:
```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-devtools</artifactId>
        <scope>runtime</scope>
        <optional>true</optional>
    </dependency>
</dependencies>
```

#### Dependency Hierarchy
- Eclipse me `pom.xml` open karo.
- **Dependency Hierarchy** tab me poora dependency tree check kar sakte ho.

---

## ✅ Output Logs Example:
```
INFO  [main] c.c.s.SpringLearnApplication - Spring Learn Application Start Ho Raha Hai...
INFO  [main] c.c.s.SpringLearnApplication - Spring Learn Application Successfully Start Ho Gaya!
```

---

## 📌 Technologies Used:
- Java 17+
- Spring Boot
- Maven
- Eclipse IDE

---
