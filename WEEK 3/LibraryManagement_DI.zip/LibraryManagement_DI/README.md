# LibraryManagement – Exercise 2 (Dependency Injection)

Demonstrates Spring IoC & setter‑based Dependency Injection between `BookService` and `BookRepository`.

## Build & Run

```bash
mvn clean package
mvn exec:java -Dexec.mainClass="com.library.LibraryManagementApplication"
```

## Expected Output

```
BookRepository: Initialized
BookService: Initialized
BookService: perform() called
BookRepository: Display method called
```

Generated 2025-07-06 09:46:29
