package com.library.repository;

public class BookRepository {
    public BookRepository() {
        System.out.println("BookRepository: Initialized");
    }

    public void display() {
        System.out.println("BookRepository: Display method called");
    }
}
