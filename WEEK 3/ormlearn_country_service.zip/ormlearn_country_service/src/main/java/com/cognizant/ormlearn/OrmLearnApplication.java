package com.cognizant.ormlearn;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;

@SpringBootApplication
public class OrmLearnApplication {

    private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    @Bean
    public CommandLineRunner testRunner(CountryService countryService) {
        return args -> {
            LOGGER.info("Testing CountryService...");

            // Fetch one country
            Country in = countryService.findCountryByCode("IN");
            LOGGER.info("findCountryByCode(IN): {}", in);

            // Add new country
            Country test = new Country("ZZ", "Testland");
            countryService.addCountry(test);
            LOGGER.info("Added: {}", test);

            // Update country
            test.setName("Testlandia");
            countryService.updateCountry(test);
            LOGGER.info("Updated: {}", test);

            // Find by partial
            List<Country> result = countryService.findCountriesByPartialName("test");
            LOGGER.info("findCountriesByPartialName('test'): {}", result);

            // Delete
            countryService.deleteCountry("ZZ");
            LOGGER.info("Deleted ZZ");

            LOGGER.info("All tests done.");
        };
    }
}
