# orm-learn – Service Layer for Country Management

Features implemented:
- Find by code
- Add new country
- Update country
- Delete country
- Search by partial name

## Build & Run

```bash
mvn clean package
mvn spring-boot:run
```

Ensure your MySQL database **ormlearn** is populated with the full country list.

## Expected Console Snippet

```
Testing CountryService...
findCountryByCode(IN): Country [code=IN, name=India]
Added: Country [code=ZZ, name=Testland]
Updated: Country [code=ZZ, name=Testlandia]
findCountriesByPartialName('test'): [Country [code=ZZ, name=Testlandia]]
Deleted ZZ
All tests done.
```

Generated on 2025-07-06 11:21:51.589942
