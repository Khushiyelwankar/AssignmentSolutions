# LibraryManagement

Minimal Spring Core (XML config) example for Exercise 1.

## Build & Run

```bash
mvn clean package
mvn exec:java -Dexec.mainClass="com.library.MainApp"
```

> Requires JDK 8+ and Maven 3.6+

## Expected Console Output

```
BookRepository: Initialized
BookService: Initialized
BookService: perform() called
BookRepository: Display method called
```

Generated on 2025-07-06 09:40:11.630608
