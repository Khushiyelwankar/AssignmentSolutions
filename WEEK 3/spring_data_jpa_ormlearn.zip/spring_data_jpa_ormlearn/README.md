# Spring Data JPA - ORM Learn Project

This project demonstrates how to use Spring Boot with Spring Data JPA and Hibernate to interact with a MySQL database.

## Technologies and Tools Used
- Spring Boot
- Spring Data JPA
- Hibernate
- MySQL Server 8.0 & Workbench
- Eclipse IDE for Enterprise Java Developers
- Maven 3.6.2

## Setup Steps

1. **Spring Initializr**:
    - Group: `com.cognizant`
    - Artifact: `orm-learn`
    - Description: "Demo project for Spring Data JPA and Hibernate"
    - Dependencies: Spring Boot DevTools, Spring Data JPA, MySQL Driver

2. **MySQL Setup**:
    - Create schema `ormlearn` in MySQL:
      ```sql
      CREATE SCHEMA ormlearn;
      ```

3. **application.properties Configuration**:
    ```properties
    spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
    spring.datasource.url=jdbc:mysql://localhost:3306/ormlearn
    spring.datasource.username=root
    spring.datasource.password=root
    spring.jpa.hibernate.ddl-auto=validate
    spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQL5Dialect
    logging.level.org.hibernate.SQL=trace
    logging.level.org.hibernate.type.descriptor.sql=trace
    ```

4. **Entity Class**: `Country.java`
    ```java
    @Entity
    @Table(name="country")
    public class Country {
        @Id
        @Column(name="code")
        private String code;

        @Column(name="name")
        private String name;

        // Getters, Setters, toString()
    }
    ```

5. **Repository Interface**: `CountryRepository.java`
    ```java
    public interface CountryRepository extends JpaRepository<Country, String> { }
    ```

6. **Service Class**: `CountryService.java`
    ```java
    @Service
    public class CountryService {
        @Autowired
        private CountryRepository countryRepository;

        @Transactional
        public List<Country> getAllCountries() {
            return countryRepository.findAll();
        }
    }
    ```

7. **Main Class**: `OrmLearnApplication.java`
    ```java
    ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
    countryService = context.getBean(CountryService.class);
    testGetAllCountries();
    ```

8. **SQL for `country` table**
    ```sql
    CREATE TABLE country (co_code VARCHAR(2) PRIMARY KEY, co_name VARCHAR(50));
    INSERT INTO country VALUES ('IN', 'India'), ('US', 'United States of America');
    ```

## Logs
Ensure that logs display SQL trace and Hibernate behavior.

## Expected Output (from main method)
```
Start
countries=[Country [code=IN, name=India], Country [code=US, name=United States of America]]
End
```

## Author: Cognizant Training Demo
